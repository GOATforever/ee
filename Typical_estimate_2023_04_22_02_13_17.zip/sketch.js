function setup() {
  createCanvas(500, 600);
}

function draw() {
  background(220);
  x = map(mouseX, 0 ,600, 0 ,255);
  y = map(mouseY, 0 ,600, 0 ,255);
  fill(x,0,y)
  ellipse(x,0,y)
  print(y);
}