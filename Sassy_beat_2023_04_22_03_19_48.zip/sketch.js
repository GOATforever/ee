function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  circle(255,255,255)
  my_ellipse(255,255,40,0,frameCount/3);
  my_ellipse(255,255,170,0,frameCount*6 );
}
function my_ellipse(x,y,w,h,d) {
  push();
  translate(x,y);
  rotate(radians(d))
  ellipse(0,0,w,h);
  pop();
}